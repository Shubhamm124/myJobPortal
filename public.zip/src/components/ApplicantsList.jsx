import React, { useState, useEffect } from "react";
import "./ApplicantsList.css";

const ApplicantsList = () => {
  const [applicants, setApplicants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch("https://dummyjson.com/users") // Replace with your real API
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
      })
      .then((data) => {
        setApplicants(data.users.slice(0, 5)); // Fetch first 5 applicants
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching applicants:", err);
        setError(err.message || "Failed to load applicants.");
        setLoading(false);
      });
  }, []);

  const handleStatusChange = (id, newStatus) => {
    setApplicants((prevApplicants) =>
      prevApplicants.map((applicant) =>
        applicant.id === id ? { ...applicant, status: newStatus } : applicant
      )
    );
  };

  if (loading) return <p>Loading applicants...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div className="applicants-container">
      <h2 className="m-3">Job Applicants</h2>
      {applicants.map((applicant) => (
        <div key={applicant.id} className="applicant-card">
          <img
            src={applicant.image}
            alt={applicant.firstName}
            className="profile-pic"
          />
          <div className="applicant-info">
            <h3>
              {applicant.firstName} {applicant.lastName}
            </h3>
            <p>
              <strong>Email:</strong> {applicant.email}
            </p>
            <p>
              <strong>Job Applied:</strong> Software Developer
            </p>
            <p>
              <strong>Experience:</strong> {Math.floor(Math.random() * 10) + 1}{" "}
              years
            </p>
            <p>
              <strong>Skills:</strong> React, Node.js, JavaScript
            </p>
            <p>
              <strong>Current Status:</strong> {applicant.status || "Pending"}
            </p>
            <div className="action-buttons">
              <button
                className="accept-btn"
                onClick={() => handleStatusChange(applicant.id, "Accepted")}
              >
                Accept
              </button>
              <button
                className="reject-btn"
                onClick={() => handleStatusChange(applicant.id, "Rejected")}
              >
                Reject
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ApplicantsList;
