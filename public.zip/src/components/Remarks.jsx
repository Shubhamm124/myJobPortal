import React from "react";

const Remarks = () => {
  return (
    <div className="container-fluid">
      <div className="row text-center">
        <div className="col">
          <div>
            <h2>Remarks of Interview</h2>
            <h3>
              We took 8 interviews on 10 February 2025 for the position of Front
              end developer
            </h3>
            <h4>Unfortunately No one is selected</h4>
            <h4>
              Please only those should Apply who have following skills :-{" "}
            </h4>
            <ul
              style={{
                listStyleType: "none",
              }}
            >
              <li>Html</li>
              <li>Css</li>
              <li>Javascript</li>
              <li>Bootstrap</li>
              <li>React</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Remarks;
